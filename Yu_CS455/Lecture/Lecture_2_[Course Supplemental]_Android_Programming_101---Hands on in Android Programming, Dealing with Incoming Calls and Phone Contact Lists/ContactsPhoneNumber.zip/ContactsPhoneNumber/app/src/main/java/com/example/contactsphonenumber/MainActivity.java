package com.example.contactsphonenumber;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 0; // This is request code 0
    String phoneNumber;
    ListView lv;
    ArrayList<String> ContactNumbersList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        grantReadContacts();

        lv = (ListView) findViewById(R.id.lv);
        getPhoneNumber(this.getContentResolver());

    }

    public void grantReadContacts() {
        System.out.println("grantReadContacts");
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS},
                    MY_PERMISSIONS_REQUEST_READ_CONTACTS);
        }
    }

    @SuppressLint("Range")
    public void getPhoneNumber(ContentResolver cr) {
        Cursor records = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        while (records.moveToNext()) {

            String name = records.getString(records.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY));

            phoneNumber = records.getString(records.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));


            System.out.println(name + " : " + phoneNumber);

            ContactNumbersList.add(name + " : " + phoneNumber);

        }

        records.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,
                ContactNumbersList);

        lv.setAdapter(adapter);

    }

}