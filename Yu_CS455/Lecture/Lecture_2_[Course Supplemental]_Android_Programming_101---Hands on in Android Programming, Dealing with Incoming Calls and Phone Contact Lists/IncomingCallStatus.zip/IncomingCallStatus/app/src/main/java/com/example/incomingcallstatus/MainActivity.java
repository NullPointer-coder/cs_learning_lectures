package com.example.incomingcallstatus;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Bundle;
import android.os.PersistableBundle;

public class MainActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_READ_PHONE_STATE = 0; // This is the request code0
    private static final int MY_PERMISSIONS_REQUEST_READ_CALL_LOG = 1; // This is the request code1
    PhoneStateReceiver PhoneStateReceiver = new PhoneStateReceiver(this);

    boolean isReadPhoneStateGranted = false;
    boolean isReadCallLogGranted = false;

    IntentFilter filter = new IntentFilter();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        System.out.println("In Main");

        filter.addAction("android.intent.action.PHONE_STATE");
        filter.addAction("android.intent.action.CALL_LOG");

        registerReceiver(PhoneStateReceiver, filter);

        grantPhoneState();

    }

    @Override
    public void onPostCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onPostCreate(savedInstanceState, persistentState);

    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isReadCallLogGranted == false) {
            grantCallLog();
        }
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    @Override
    protected void onDestroy() {
        if (PhoneStateReceiver != null) {
            unregisterReceiver(PhoneStateReceiver);
            PhoneStateReceiver = null;
        }
        super.onDestroy();
    }


    public void grantPhoneState() {
        System.out.println("grantPhoneState");
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE},
                    MY_PERMISSIONS_REQUEST_READ_PHONE_STATE);

        } else {
            // The permission of READ_PHONE_STATE is granted
            isReadPhoneStateGranted = true;
        }

    }

    public void grantCallLog() {
        System.out.println("grantCallLog");
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_CALL_LOG)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CALL_LOG},
                    MY_PERMISSIONS_REQUEST_READ_CALL_LOG);

        } else {
            // The permission of READ_CALL_LOG is granted
            isReadCallLogGranted = true;
        }
    }

}