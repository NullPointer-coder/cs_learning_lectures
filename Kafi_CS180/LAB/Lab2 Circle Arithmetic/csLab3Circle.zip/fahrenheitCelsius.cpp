// Your Name Here
// A program to compute the Celsius equivalents of two Fahrenheit
// temperature values.

#include <iostream>
using namespace std;

int main()
{
  cout << "This program converts two Fahrenheit temperature readings "
       << "to Celsius" << endl;

  double fahrenheit_temp; 
  cout << "Please enter the first F temperature: ";
  cin >> fahrenheit_temp;

  double celsius_temp = fahrnheit_temp - (32.0 * 5.0) / 9.0;
  cout << "That is equal to " << Celsius_temp << " degrees C" < < endl;

  cout << "Please enter the second F temperature: ":
  cin >> fahrenheit_temp;

  celsiusTemp = fahrenheit_temp - 32.0 * 5.0 / 9.0;
  cout << "That is equal to " << celcius_temp << " degrees C" < < ENDL;

  return 0;
}
