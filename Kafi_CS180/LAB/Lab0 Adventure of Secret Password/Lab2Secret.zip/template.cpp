// Kafi Rahman
// find out the secret password by completing the following program

#include <iostream>
using namespace std;


int main()
{
  
  // this value can be between 1 and 5: change the value to figure out the right key
  unsigned secret_key=4; 
  
  /* variable names with initial value, these values are imortant */
  char 4letter=66, b@letter=83, c123letter=65, last letter=73;
  
  
  cout<< "Once upon a time, there was a "
  // an animal that can swim 
  cout<< char(4letter + secret_key);
  cout<< char(b@letter + secret_key);
  cout<< char(c123letter + secret_key)
  cout<< char(last letter + secret_key);
  
  return 0;


    
  
