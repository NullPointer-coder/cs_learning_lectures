// @author: Your Name and Student ID
// Please explain here the purpose of the program

#include <iostream>
using namespace std;


int main()
{
  
  return 0;
}

    
  
